### =============================================================================== ###
### This script can export and import event from/into a Dollar Universe 6           ###
###                                                                                 ###
###   Expected arguments:                                                           ###
###                                                                                 ###
###   To Export:                                                                    ###
###        -export <FILENAME> <AREA> <NODE>                                         ###
###                                                                                 ###
###   To Import:                                                                    ###
###       -import <FILENAME> <AREA> <NODE>                                          ###
###                                                                                 ###
###   <AREA> and <NODENAME> are optional                                            ###
### =============================================================================== ###

### =============================================================================== ###
### Init and config ###
my $ooo=";";


### =============================================================================== ###
### Parameters ###
my $nb_arg=scalar @ARGV;
if ($nb_arg<2) {
    error_arguments();
}

my $ACTION = $ARGV[0];
if (($ACTION ne "-export") and ($ACTION ne "-import")) {
    error_arguments();
}

my $FILE = $ARGV[1];

my $AREA_FILTER = $ARGV[2];

my $NODE_FILTER = "";
if ($nb_arg>3) {
    $NODE_FILTER = "node=".$ARGV[3];
}

### =============================================================================== ###
### Main procedure ###

### Case: Export

if ($ACTION eq "-export") {

    print("\nExporting the list of events to: ".$FILE."\n\n");

    # Get the list of events
    open(STDERR, ">err.log");
    my $EVT_LIST = `$ENV{'UNI_DIR_EXEC'}/uxlst EVT $AREA_FILTER $NODE_FILTER FULL`;
    my @EVT_LIST = split('\n', $EVT_LIST);

    # Init file out
    open(FILE_OUT, '>>' , $FILE) or die "$!";;
    
    # Parse the list of events
    my $LINE_NUM = 0;
    foreach my $LINE (@EVT_LIST) {

        $LINE_NUM++;
        if ($LINE_NUM>4) {
            # print($LINE."\n");
            
            # Get the fields for each line
            my $TASK    =trim_substr($LINE,0,64);
            my $SESSION =trim_substr($LINE,65,64);
            my $UPROC   =trim_substr($LINE,130,64);
            my $MU      =trim_substr($LINE,195,64);
            my $STATUS  =trim_substr($LINE,260,20);
            my $PDATE   =trim_substr($LINE,281,10);
            
            my $USER    =trim_substr($LINE,318,64);
            my $NUMSESS =trim_substr($LINE,383,7);
            my $NUMPROC =trim_substr($LINE,391,7);
            
            print FILE_OUT $TASK.$ooo.$SESSION.$ooo.$UPROC.$ooo.$MU.$ooo.$STATUS.$ooo.$PDATE.$ooo.$USER.$ooo.$NUMSESS.$ooo.$NUMPROC."\n";
        }
    }
    
    # Close file
    close(FILE_OUT);


    
### Case: import
    
} elsif ($ACTION eq "-import") {

    print("\nImporting the list of events from: ".$FILE."\n\n");
    
    # Process the input file, line by line
    open(FILE_IN,  '<' , $FILE) or die "$!";
    while(<FILE_IN>) {  
    
        $LINE = $_;
        
        # Get the fiels
        my @values  = split(';', $LINE);
        my $TASK    = @values[0];
        my $SESSION = @values[1];
        my $UPROC   = "UPR=\"".@values[2]."\"";
        my $MU      = "MU=\"".@values[3]."\"";
        my $STATUS  = @values[4];
        my $PDATE   = "PDATE=".@values[5];
        my $USER    = "USER=".@values[6];
        my $NUMSESS = @values[7];
        my $NUMPROC = @values[8];
    
        # Format the field for the command
        if ($TASK ne "") {
            $TASK = "TSK=\"".$TASK."\"";
        }
        if ($SESSION ne "") {
            $SESSION = "SES=\"".$SESSION."\"";
        }
        if ($STATUS eq "COMPLETED") {
            $STATUS = "NSTAT=T";
        } elsif ($STATUS eq "ABORTED") {
            $STATUS = "NSTAT=A";
        } elsif ($STATUS eq "RUNNING") {
            $STATUS = "NSTAT=E";
        } elsif ($STATUS eq "PENDING") {
            $STATUS = "NSTAT=P";
        } elsif ($STATUS eq "EVENT WAIT") {
            $STATUS = "NSTAT=S";
        }
        if ($NUMSESS ne "0000000") {
            $NUMSESS = "NSESS=".@values[7];
        } else {
            $NUMSESS = "";
        }
        
        # Execute the add command
        my $EVT_ADD = `$ENV{'UNI_DIR_EXEC'}/uxadd EVT $AREA_FILTER $NODE_FILTER $TASK $SESSION $UPROC $MU $STATUS $PDATE $USER $NUMSESS `;
        print("uxadd EVT $AREA_FILTER $NODE_FILTER $TASK $SESSION $UPROC $MU $STATUS $PDATE $USER $NUMSESS\n");
        print($EVT_ADD);        
        
    }
    close(FILE_IN);

}

exit(0);


### =============================================================================== ###
### Functions ###

## Exit in error because not the right script arguments
sub error_arguments {
    print("\n");
    print("Error: incorrect argments\n");
    print("\n");
    print("  Expected arguments:\n");
    print("\n");
    print("  To Export:\n");
    print("    -export <FILENAME> <AREA> <NODE>\n");
    print("\n");
    print("  To Import:\n");
    print("    -import <FILENAME> <AREA> <NODE>\n");
    print("\n");
    print("  <AREA> and <NODENAME> are optional");
    print("\n");
    exit 1;
}

## Get a substring and trim it
# Parameters
# 1- string
# 2- start position
# 3- end position
sub  trim_substr { 
    # Parameters
    my $string = $_[0];
    my $start  = $_[1];
    my $end    = $_[2];
    # Substring then trim    
    $s = substr($string,$start,$end);
    $s =~ s/^\s+|\s+$//g; 
    return $s 
};